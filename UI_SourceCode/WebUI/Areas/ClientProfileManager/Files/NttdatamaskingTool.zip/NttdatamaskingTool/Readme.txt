This data masking simple tool is to mask the PI data in input file. Onetime regular expressions to be configured for known PI data elements. User has to provide the source XL file to be masked; all the columns from source file would get displayed, user can select the column(s) to be masked and opt for masking. It takes several minutes to mask the data in output file, it depending on number of records and number of PI data present in the source file.

Configuration to run the exe application.
1. Tool would be shipped with pre configured for known PI data elements(which are stored in RegExStore.xml file.). This xml file is present in the main folder.
2. NTTDataMasking.exe file in '\bin' folder is the application user should use(they can create a desktop shortcut).
3. Masked file would get copied to destination folder with the prefix 'Masked_'.

S/W Requirement
-.NET framework 4.5
- Microsoft ACE Provider 12.0 should present in client desktop; this can be downloaded from https://www.microsoft.com/en-us/download/details.aspx?id=13255.







